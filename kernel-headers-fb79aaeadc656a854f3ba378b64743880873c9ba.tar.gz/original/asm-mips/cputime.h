#ifndef __MIPS_CPUTIME_H
#define __MIPS_CPUTIME_H

#include <asm-generic/cputime.h>

#endif /* __MIPS_CPUTIME_H */
