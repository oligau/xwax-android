#ifndef _ASM_SECTIONS_H
#define _ASM_SECTIONS_H

#include <asm-generic/sections.h>

#endif /* _ASM_SECTIONS_H */
