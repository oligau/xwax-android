#ifndef __ASM_PERCPU_H
#define __ASM_PERCPU_H

#include <asm-generic/percpu.h>

#endif /* __ASM_PERCPU_H */
