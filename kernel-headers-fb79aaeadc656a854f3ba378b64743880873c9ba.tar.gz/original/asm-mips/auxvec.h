#ifndef _ASM_AUXVEC_H
#define _ASM_AUXVEC_H

#endif /* _ASM_AUXVEC_H */
