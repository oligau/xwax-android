#ifndef _ASMARM_SIGINFO_H
#define _ASMARM_SIGINFO_H

#include <asm-generic/siginfo.h>

#endif
