#ifndef __ARM_CPUTIME_H
#define __ARM_CPUTIME_H

#include <asm-generic/cputime.h>

#endif /* __ARM_CPUTIME_H */
