#ifndef _ASMARM_SUSPEND_H
#define _ASMARM_SUSPEND_H

#endif
