#ifdef CONFIG_X86_32
# include "string_32.h"
#else
# include "string_64.h"
#endif
