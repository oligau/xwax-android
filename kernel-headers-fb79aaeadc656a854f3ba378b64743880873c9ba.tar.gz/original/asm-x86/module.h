#ifdef CONFIG_X86_32
# include "module_32.h"
#else
# include "module_64.h"
#endif
