#ifdef CONFIG_X86_32
# include "hw_irq_32.h"
#else
# include "hw_irq_64.h"
#endif
