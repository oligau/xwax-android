#ifdef CONFIG_X86_32
# include "pgalloc_32.h"
#else
# include "pgalloc_64.h"
#endif
