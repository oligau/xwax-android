#ifdef CONFIG_X86_32
# include "io_32.h"
#else
# include "io_64.h"
#endif
