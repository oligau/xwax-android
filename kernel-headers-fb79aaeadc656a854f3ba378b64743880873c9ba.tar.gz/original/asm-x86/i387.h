#ifdef CONFIG_X86_32
# include "i387_32.h"
#else
# include "i387_64.h"
#endif
