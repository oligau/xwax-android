#ifdef CONFIG_X86_32
# include "semaphore_32.h"
#else
# include "semaphore_64.h"
#endif
