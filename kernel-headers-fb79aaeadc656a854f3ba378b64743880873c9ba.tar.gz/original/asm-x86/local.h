#ifdef CONFIG_X86_32
# include "local_32.h"
#else
# include "local_64.h"
#endif
