#ifdef CONFIG_X86_32
# include "scatterlist_32.h"
#else
# include "scatterlist_64.h"
#endif
