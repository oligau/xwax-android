#ifdef CONFIG_X86_32
# include "irq_32.h"
#else
# include "irq_64.h"
#endif
