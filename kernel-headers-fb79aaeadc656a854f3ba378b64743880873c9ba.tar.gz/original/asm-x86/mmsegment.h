#ifndef _ASM_MMSEGMENT_H
#define _ASM_MMSEGMENT_H 1

typedef struct {
	unsigned long seg;
} mm_segment_t;

#endif
