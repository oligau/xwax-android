#ifdef CONFIG_X86_32
# include "linkage_32.h"
#else
# include "linkage_64.h"
#endif
