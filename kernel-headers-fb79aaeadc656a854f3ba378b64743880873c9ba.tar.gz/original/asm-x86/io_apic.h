#ifdef CONFIG_X86_32
# include "io_apic_32.h"
#else
# include "io_apic_64.h"
#endif
