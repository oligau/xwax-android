#ifdef CONFIG_X86_32
# include "mc146818rtc_32.h"
#else
# include "mc146818rtc_64.h"
#endif
