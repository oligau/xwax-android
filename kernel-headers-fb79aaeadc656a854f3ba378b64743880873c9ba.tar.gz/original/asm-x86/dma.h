#ifdef CONFIG_X86_32
# include "dma_32.h"
#else
# include "dma_64.h"
#endif
