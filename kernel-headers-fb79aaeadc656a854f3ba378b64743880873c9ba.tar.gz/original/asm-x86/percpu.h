#ifdef CONFIG_X86_32
# include "percpu_32.h"
#else
# include "percpu_64.h"
#endif
