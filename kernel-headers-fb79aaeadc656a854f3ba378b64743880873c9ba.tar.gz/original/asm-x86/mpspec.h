#ifdef CONFIG_X86_32
# include "mpspec_32.h"
#else
# include "mpspec_64.h"
#endif
