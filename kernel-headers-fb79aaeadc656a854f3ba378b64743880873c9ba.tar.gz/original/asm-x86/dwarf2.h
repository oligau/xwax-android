#ifdef CONFIG_X86_32
# include "dwarf2_32.h"
#else
# include "dwarf2_64.h"
#endif
