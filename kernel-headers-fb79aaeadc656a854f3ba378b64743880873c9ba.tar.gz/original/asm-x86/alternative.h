#ifdef CONFIG_X86_32
# include "alternative_32.h"
#else
# include "alternative_64.h"
#endif
