#ifdef CONFIG_X86_32
# include "apic_32.h"
#else
# include "apic_64.h"
#endif
