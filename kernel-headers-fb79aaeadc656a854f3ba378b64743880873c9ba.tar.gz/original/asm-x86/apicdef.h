#ifdef CONFIG_X86_32
# include "apicdef_32.h"
#else
# include "apicdef_64.h"
#endif
