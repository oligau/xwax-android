#ifdef CONFIG_X86_32
# include "irqflags_32.h"
#else
# include "irqflags_64.h"
#endif
