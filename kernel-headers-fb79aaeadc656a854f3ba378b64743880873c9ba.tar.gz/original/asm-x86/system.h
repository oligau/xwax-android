#ifdef CONFIG_X86_32
# include "system_32.h"
#else
# include "system_64.h"
#endif
