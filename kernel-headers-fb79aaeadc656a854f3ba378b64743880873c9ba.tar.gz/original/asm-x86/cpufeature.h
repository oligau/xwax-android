#ifdef CONFIG_X86_32
# include "cpufeature_32.h"
#else
# include "cpufeature_64.h"
#endif
