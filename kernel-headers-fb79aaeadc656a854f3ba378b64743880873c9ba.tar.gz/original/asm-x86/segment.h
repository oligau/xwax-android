#ifdef CONFIG_X86_32
# include "segment_32.h"
#else
# include "segment_64.h"
#endif
