#ifdef CONFIG_X86_32
# include "desc_32.h"
#else
# include "desc_64.h"
#endif
