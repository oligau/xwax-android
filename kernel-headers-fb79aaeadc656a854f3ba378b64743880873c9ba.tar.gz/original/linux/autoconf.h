#ifndef LINUX_AUTOCONF_CRAP_GOES_HERE
#define LINUX_AUTOCONF_CRAP_GOES_HERE

/* we're not using this to build kernel stuff, so a subset should do */

#define AUTOCONF_INCLUDED

#endif
